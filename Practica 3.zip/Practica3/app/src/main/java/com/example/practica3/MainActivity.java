package com.example.practica3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

            private final String[] fruits = {"Manzana", "Naranja", "Plátano", "Fresa", "Piña", "Sandía", "Mango", "Uva", "Melón", "Kiwi"};
            private final double[] costos = {1.0, 0.8, 0.5, 1.5, 2.0, 1.2, 1.8, 1.3, 1.0, 0.9};
            private final int[] images = {R.drawable.manzana, R.drawable.naranja, R.drawable.platano, R.drawable.fresa,
                    R.drawable.pina, R.drawable.sandia, R.drawable.mango, R.drawable.uva,
                    R.drawable.melon, R.drawable.kiwi};

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                ListView listView = findViewById(R.id.listView);

                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, fruits);
                listView.setAdapter(adapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                        String selectedFruta = fruits[position];
                        Toast.makeText(MainActivity.this, "Se agregó " + selectedFruta + " al carrito", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }

    }
}